package com.seriesModelService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.seriesModelService.DAO.SMSDao;

@RestController
@RequestMapping("/seriesModelService")
public class SMSController {
	
	@Autowired
	private SMSDao sms;
	
	@GetMapping("/home")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> home(){
		List<String> series=sms.findAllSeries();
		return series;
	}
	
	@GetMapping("/series")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> findAllSeries(){
		List<String> series=sms.findAllSeries();
		return series;
	}
	
	@GetMapping("/modelyear/{series}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> findModelYear(@PathVariable String series){
		List<String> year=sms.findModelYearBySeries(series);
		return year;
	}
	
	@GetMapping("/modelcode/{series}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> findModelCode(@PathVariable String series){
		List<String> mcode=sms.findModelCodeBySeries(series);
		return mcode;
	}
	
	@GetMapping("/modelcode/{series}/{year}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> findModelCode(@PathVariable String series,@PathVariable String year){
		List<String> mcode=sms.findModelCodeBySeriesAndYear(series, year);
		return mcode;
	}
	
	@GetMapping("/accessory/{modelCode}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<String> readAllModels(@PathVariable String modelCode){
		System.out.println(modelCode);
		List<String> acces=sms.findAccessoryByModelCode(modelCode);
		return acces;
	}
	
}
