package com.accessoryService.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.accessoryService.model.Sales;

public class SalesRowMapper implements RowMapper<Sales> {

	@Override
	public Sales mapRow(ResultSet rs, int rowNum) throws SQLException {
		Sales sale=new Sales(rs.getString(1),rs.getString(2),rs.getString(3),rs.getInt(4));
		return sale;
	}

}
