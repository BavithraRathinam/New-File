package com.accessoryService.DAO;

import java.sql.Date;
import java.util.List;

import org.springframework.context.annotation.Configuration;

import com.accessoryService.model.Sales;

@Configuration
public interface SalesDAO {
	
	public List<Sales> findHighSaleVehicle(Date sdate,Date edate);
	
	public List<Sales> findLowSaleVehicle(Date sdate,Date edate);
	
	public List<Sales> findByConstraints(Date sdate,Date edate,String modelSeriesYear);

	public List<Sales> findAccessories(Date sdate, Date edate, String access);

	public String findHighSaleVehicleByModelCode(Date sdate, Date edate);
	
	public String findLowSaleVehicleByModelCode(Date sdate, Date edate);
	
	public List<Sales> findHighSaleAccessory(String accessory,Date sdate, Date edate);

	public Integer findAccessorySaleCount(String accessory,Date sdate, Date edate);

}
