package com.accessoryService.model;


public class Sales {
	
	private String modelSeriesYear;
	private String year;
	private String region;
	private int saleCount;
	public String getModelSeriesYear() {
		return modelSeriesYear;
	}
	public void setModelSeriesYear(String modelSeriesYear) {
		this.modelSeriesYear = modelSeriesYear;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public int getSaleCount() {
		return saleCount;
	}
	public void setSaleCount(int saleCount) {
		this.saleCount = saleCount;
	}
	public Sales(String modelSeriesYear, String year, String region, int saleCount) {
		super();
		this.modelSeriesYear = modelSeriesYear;
		this.year = year;
		this.region = region;
		this.saleCount = saleCount;
	}

	
}
