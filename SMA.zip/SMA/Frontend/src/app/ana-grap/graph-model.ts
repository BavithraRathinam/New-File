export class Graph{
    name:string;
    series:{name:string,value:number}[];
    constructor(modelCode:string,pair:{name:string,value:number}[]){
        this.name=modelCode;
        this.series=pair;
    }
}