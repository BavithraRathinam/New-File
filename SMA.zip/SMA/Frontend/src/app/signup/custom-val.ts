import {FormGroup} from '@angular/forms';

export function MustMatch(name: string, matchname:string){
    return (formGroup: FormGroup)=>{
        const text=formGroup.controls[name];
        const matchtext=formGroup.controls[matchname];

        if(matchtext.errors && !matchtext.errors.mustMatch){
            return;
        }

        if(text.value !== matchtext.value){
            matchtext.setErrors({mustMatch:true});
        }else{
            matchtext.setErrors(null);
        }

    }
}