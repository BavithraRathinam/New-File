import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  signInForm:FormGroup;
  router:Router;

  constructor(private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.signInForm=this.formBuilder.group({
      'username':[null,Validators.required],
      'password':[null,[Validators.required]]
    });
  }

  loginAdmin() {
    this.router.navigate(['admin']);
    //this.navbarService.updateNavAfterAuth('admin');
    //this.navbarService.updateLoginStatus(true,'admin');
    //this.role = 'admin';
  }

}
