import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  signInForm:FormGroup;
  router:Router;

  constructor(private formBuilder:FormBuilder) { }

  ngOnInit(): void {
    this.signInForm=this.formBuilder.group({
      'username':[null,Validators.required],
      'password':[null,[Validators.required]]
    });
  }

  loginUser() {
    this.router.navigate(['user']);
    //this.navbarService.updateNavAfterAuth('user');
    //this.navbarService.updateLoginStatus(true,'user');
    //this.role = 'user';
  }

}
