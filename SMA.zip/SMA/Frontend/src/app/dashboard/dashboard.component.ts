import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Graph} from '../ana-grap/graph-model';
import * as html2pdf from 'html2pdf.js';
//import * as jsPDF from 'jspdf';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  highsale:any[];
  lowsale:any[];
  highsaleacc:any[];
  lowsaleacc:any[];
  highapi: string='http://localhost:9090/accessoryService/highSales/2015-01-01/2018-12-31';
  lowapi: string='http://localhost:9090/accessoryService/lowSales/2015-01-01/2018-12-31';
  highacc: string='http://localhost:9090/accessoryService/accessoriesMax/2015-01-01/2018-12-31';
  lowacc: string='http://localhost:9090/accessoryService/accessoriesMin/2015-01-01/2018-12-31';

  constructor(private http:HttpClient) {
    this.getHighSale(this.highapi);
    this.getLowSale(this.lowapi);
    this.getHighSaleAcc(this.highacc);
    this.getLowSaleAcc(this.lowacc);

   }

  ngOnInit(): void {
  }

  getHighSale(apiURL) {
    const promise = new Promise((resolve, reject) => {
      this.http
        .get<string[]>(apiURL)
        .toPromise()
        .then((resp: any) => {
          this.highsale = resp.map((res: any) => {
            return new Graph(res.region,res.series);
          });
          resolve();
        },
          err => {
            reject(err);
          }
        );
    });
    return promise;
  }
  getLowSale(apiURL) {
    const promise = new Promise((resolve, reject) => {
      this.http
        .get<string[]>(apiURL)
        .toPromise()
        .then((resp: any) => {
          this.lowsale = resp.map((res: any) => {
            return new Graph(res.region,res.series);
          });
          resolve();
        },
          err => {
            reject(err);
          }
        );
    });
    return promise;
  }
  getHighSaleAcc(apiURL) {
    const promise = new Promise((resolve, reject) => {
      this.http
        .get<string[]>(apiURL)
        .toPromise()
        .then((resp: any) => {
          this.highsaleacc = resp.map((res: any) => {
            return new Graph(res.region,res.series);
          });
          resolve();
        },
          err => {
            reject(err);
          }
        );
    });
    return promise;
  }
  getLowSaleAcc(apiURL) {
    const promise = new Promise((resolve, reject) => {
      this.http
        .get<string[]>(apiURL)
        .toPromise()
        .then((resp: any) => {
          this.lowsaleacc = resp.map((res: any) => {
            return new Graph(res.region,res.series);
          });
          resolve();
        },
          err => {
            reject(err);
          }
        );
    });
    return promise;
  }
 
  @ViewChild('gpdf') content:ElementRef;
  generatePdf(){

   /* let doc = new jsPDF();

    let spcl={
      '#editor':function(element,renderer){
        return true;
      }
    };
    let content=this.content.nativeElement;
    doc.fromHTML(content.innerHTML,15,15,{
      'width':190,
      'elementHandlers':spcl
    });
    doc.save('sms.pdf');*/
    const options={
      margin:       1,
      filename:     'sales-matrics.pdf',
      image:        { type: 'jpeg', quality: 1 },
      html2canvas:  { scale: 2,allowTaint: false,imageTimeout:0 },
      jsPDF:        { unit: 'in',format: 'A4', orientation: 'portrait' }

    }
    //console.log(options);
    const element:Element=document.getElementById('pdf');
    /*html2pdf().from(element).set(options).toPdf()
    .output('datauristring').then(function (pdfAsString) {
      // The PDF has been converted to a Data URI string and passed to this function.
      // Use pdfAsString however you like (send as email, etc)! For instance:
      //console.log(pdfAsString);
      //console.log(pdfAsString);
    });*/
    

    html2pdf().from(element).set(options).save();
    //html2pdf().from().toContainer(element).toCanvas().toImg().toPdf().save();
    //html2pdf().from(element).set(options).save();
    
      
    
  }


}
